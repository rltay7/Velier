import { sqliteTable, text, integer, real } from "drizzle-orm/sqlite-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Users table
export const users = sqliteTable("users", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  name: text("name").notNull(),
  email: text("email").notNull().unique(),
  avatar: text("avatar"),
  bio: text("bio"),
  location: text("location"),
  rating: real("rating").default(5.0),
  reviewCount: integer("review_count").default(0),
  verified: integer("verified", { mode: "boolean" }).default(false),
});

export const insertUserSchema = createInsertSchema(users).omit({ id: true });
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Listings table
export const listings = sqliteTable("listings", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  ownerId: integer("owner_id").notNull(),
  title: text("title").notNull(),
  brand: text("brand").notNull(),
  category: text("category").notNull(), // bags, watches, dresses, jewellery, shoes
  description: text("description").notNull(),
  images: text("images").notNull(), // JSON array of image URLs
  pricePerDay: real("price_per_day").notNull(),
  retailValue: real("retail_value").notNull(),
  condition: text("condition").notNull(), // mint, excellent, good
  size: text("size"),
  color: text("color"),
  location: text("location").notNull(),
  available: integer("available", { mode: "boolean" }).default(true),
  rating: real("rating").default(5.0),
  reviewCount: integer("review_count").default(0),
  featured: integer("featured", { mode: "boolean" }).default(false),
});

export const insertListingSchema = createInsertSchema(listings).omit({ id: true });
export type InsertListing = z.infer<typeof insertListingSchema>;
export type Listing = typeof listings.$inferSelect;

// Bookings table
export const bookings = sqliteTable("bookings", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  listingId: integer("listing_id").notNull(),
  renterId: integer("renter_id").notNull(),
  startDate: text("start_date").notNull(),
  endDate: text("end_date").notNull(),
  totalPrice: real("total_price").notNull(),
  serviceFee: real("service_fee").notNull(),
  status: text("status").notNull().default("pending"), // pending, confirmed, active, completed, cancelled
  message: text("message"),
});

export const insertBookingSchema = createInsertSchema(bookings).omit({ id: true });
export type InsertBooking = z.infer<typeof insertBookingSchema>;
export type Booking = typeof bookings.$inferSelect;
