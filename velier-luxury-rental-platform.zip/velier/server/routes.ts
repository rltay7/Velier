import type { Express } from "express";
import { type Server } from "http";
import { storage } from "./storage";
import { insertListingSchema, insertBookingSchema, insertUserSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(httpServer: Server, app: Express): Promise<Server> {
  // GET /api/listings
  app.get("/api/listings", (req, res) => {
    const { category, brand, search } = req.query;
    const listings = storage.getListings({
      category: category as string,
      brand: brand as string,
      search: search as string,
    });
    res.json(listings);
  });

  // GET /api/listings/featured
  app.get("/api/listings/featured", (req, res) => {
    const featured = storage.getFeaturedListings();
    res.json(featured);
  });

  // GET /api/listings/:id
  app.get("/api/listings/:id", (req, res) => {
    const id = parseInt(req.params.id);
    const listing = storage.getListing(id);
    if (!listing) return res.status(404).json({ message: "Listing not found" });
    res.json(listing);
  });

  // POST /api/listings
  app.post("/api/listings", (req, res) => {
    const result = insertListingSchema.safeParse(req.body);
    if (!result.success) return res.status(400).json({ message: "Invalid listing data", errors: result.error.issues });
    const listing = storage.createListing(result.data);
    res.status(201).json(listing);
  });

  // GET /api/users/:id
  app.get("/api/users/:id", (req, res) => {
    const id = parseInt(req.params.id);
    const user = storage.getUser(id);
    if (!user) return res.status(404).json({ message: "User not found" });
    res.json(user);
  });

  // POST /api/users
  app.post("/api/users", (req, res) => {
    const result = insertUserSchema.safeParse(req.body);
    if (!result.success) return res.status(400).json({ message: "Invalid user data" });
    const existing = storage.getUserByEmail(result.data.email);
    if (existing) return res.json(existing);
    const user = storage.createUser(result.data);
    res.status(201).json(user);
  });

  // POST /api/bookings
  app.post("/api/bookings", (req, res) => {
    const result = insertBookingSchema.safeParse(req.body);
    if (!result.success) return res.status(400).json({ message: "Invalid booking data", errors: result.error.issues });
    const booking = storage.createBooking(result.data);
    res.status(201).json(booking);
  });

  // GET /api/bookings/renter/:id
  app.get("/api/bookings/renter/:id", (req, res) => {
    const id = parseInt(req.params.id);
    const bookings = storage.getBookingsByRenter(id);
    res.json(bookings);
  });

  // GET /api/bookings/listing/:id
  app.get("/api/bookings/listing/:id", (req, res) => {
    const id = parseInt(req.params.id);
    const bookings = storage.getBookingsByListing(id);
    res.json(bookings);
  });

  // PATCH /api/bookings/:id/status
  app.patch("/api/bookings/:id/status", (req, res) => {
    const id = parseInt(req.params.id);
    const { status } = req.body;
    const booking = storage.updateBookingStatus(id, status);
    if (!booking) return res.status(404).json({ message: "Booking not found" });
    res.json(booking);
  });

  // GET /api/owner/:id/listings
  app.get("/api/owner/:id/listings", (req, res) => {
    const id = parseInt(req.params.id);
    const listings = storage.getListingsByOwner(id);
    res.json(listings);
  });

  return httpServer;
}
