import { drizzle } from "drizzle-orm/better-sqlite3";
import Database from "better-sqlite3";
import { eq, like, and, or } from "drizzle-orm";
import { users, listings, bookings, type User, type InsertUser, type Listing, type InsertListing, type Booking, type InsertBooking } from "@shared/schema";

const sqlite = new Database("rentle.db");
const db = drizzle(sqlite);

// Create tables
sqlite.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE,
    avatar TEXT,
    bio TEXT,
    location TEXT,
    rating REAL DEFAULT 5.0,
    review_count INTEGER DEFAULT 0,
    verified INTEGER DEFAULT 0
  );

  CREATE TABLE IF NOT EXISTS listings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    owner_id INTEGER NOT NULL,
    title TEXT NOT NULL,
    brand TEXT NOT NULL,
    category TEXT NOT NULL,
    description TEXT NOT NULL,
    images TEXT NOT NULL,
    price_per_day REAL NOT NULL,
    retail_value REAL NOT NULL,
    condition TEXT NOT NULL,
    size TEXT,
    color TEXT,
    location TEXT NOT NULL,
    available INTEGER DEFAULT 1,
    rating REAL DEFAULT 5.0,
    review_count INTEGER DEFAULT 0,
    featured INTEGER DEFAULT 0
  );

  CREATE TABLE IF NOT EXISTS bookings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    listing_id INTEGER NOT NULL,
    renter_id INTEGER NOT NULL,
    start_date TEXT NOT NULL,
    end_date TEXT NOT NULL,
    total_price REAL NOT NULL,
    service_fee REAL NOT NULL,
    status TEXT NOT NULL DEFAULT 'pending',
    message TEXT
  );
`);

export interface IStorage {
  // Users
  getUser(id: number): User | undefined;
  getUserByEmail(email: string): User | undefined;
  createUser(user: InsertUser): User;
  
  // Listings
  getListings(filters?: { category?: string; brand?: string; search?: string }): Listing[];
  getListing(id: number): Listing | undefined;
  getListingsByOwner(ownerId: number): Listing[];
  createListing(listing: InsertListing): Listing;
  getFeaturedListings(): Listing[];
  
  // Bookings
  getBooking(id: number): Booking | undefined;
  getBookingsByRenter(renterId: number): Booking[];
  getBookingsByListing(listingId: number): Booking[];
  createBooking(booking: InsertBooking): Booking;
  updateBookingStatus(id: number, status: string): Booking | undefined;
}

export class Storage implements IStorage {
  getUser(id: number): User | undefined {
    return db.select().from(users).where(eq(users.id, id)).get();
  }

  getUserByEmail(email: string): User | undefined {
    return db.select().from(users).where(eq(users.email, email)).get();
  }

  createUser(user: InsertUser): User {
    return db.insert(users).values(user).returning().get();
  }

  getListings(filters?: { category?: string; brand?: string; search?: string }): Listing[] {
    if (!filters || (!filters.category && !filters.brand && !filters.search)) {
      return db.select().from(listings).where(eq(listings.available, true)).all();
    }
    
    const conditions = [eq(listings.available, true)];
    
    if (filters.category && filters.category !== 'all') {
      conditions.push(eq(listings.category, filters.category));
    }
    
    if (filters.brand) {
      conditions.push(like(listings.brand, `%${filters.brand}%`));
    }
    
    if (filters.search) {
      conditions.push(
        or(
          like(listings.title, `%${filters.search}%`),
          like(listings.brand, `%${filters.search}%`),
          like(listings.description, `%${filters.search}%`)
        )!
      );
    }
    
    return db.select().from(listings).where(and(...conditions)).all();
  }

  getListing(id: number): Listing | undefined {
    return db.select().from(listings).where(eq(listings.id, id)).get();
  }

  getListingsByOwner(ownerId: number): Listing[] {
    return db.select().from(listings).where(eq(listings.ownerId, ownerId)).all();
  }

  createListing(listing: InsertListing): Listing {
    return db.insert(listings).values(listing).returning().get();
  }

  getFeaturedListings(): Listing[] {
    return db.select().from(listings).where(and(eq(listings.featured, true), eq(listings.available, true))).all();
  }

  getBooking(id: number): Booking | undefined {
    return db.select().from(bookings).where(eq(bookings.id, id)).get();
  }

  getBookingsByRenter(renterId: number): Booking[] {
    return db.select().from(bookings).where(eq(bookings.renterId, renterId)).all();
  }

  getBookingsByListing(listingId: number): Booking[] {
    return db.select().from(bookings).where(eq(bookings.listingId, listingId)).all();
  }

  createBooking(booking: InsertBooking): Booking {
    return db.insert(bookings).values(booking).returning().get();
  }

  updateBookingStatus(id: number, status: string): Booking | undefined {
    return db.update(bookings).set({ status }).where(eq(bookings.id, id)).returning().get();
  }
}

// Seed data
function seedDatabase(storage: Storage) {
  const existingUser = storage.getUserByEmail("demo@rentle.com");
  if (existingUser) return;

  const owner = storage.createUser({
    name: "Camille Laurent",
    email: "demo@rentle.com",
    avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&h=200&fit=crop&crop=face",
    bio: "Luxury fashion curator with 8 years in the industry. Every piece in my collection is authenticated and impeccably maintained.",
    location: "Sydney, NSW",
    rating: 4.9,
    reviewCount: 142,
    verified: true,
  });

  const owner2 = storage.createUser({
    name: "James Harrington",
    email: "james@rentle.com",
    avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&h=200&fit=crop&crop=face",
    bio: "Collector of fine timepieces and haute couture. Sharing my curated wardrobe with Melbourne's fashion community.",
    location: "Melbourne, VIC",
    rating: 4.8,
    reviewCount: 87,
    verified: true,
  });

  const renter = storage.createUser({
    name: "Sofia Marchetti",
    email: "user@rentle.com",
    avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=200&h=200&fit=crop&crop=face",
    bio: "Fashion enthusiast and event planner.",
    location: "Brisbane, QLD",
    rating: 5.0,
    reviewCount: 23,
    verified: true,
  });

  const seedListings = [
    {
      ownerId: owner.id,
      title: "Prada Re-Edition 2005 Nylon Bag",
      brand: "Prada",
      category: "bags",
      description: "The iconic Prada Re-Edition 2005 nylon shoulder bag in classic black. Authenticated with Prada dust bag and authenticity card. Perfect condition with minimal signs of wear. A timeless piece that elevates any ensemble.",
      images: JSON.stringify([
        "https://images.unsplash.com/photo-1584917865442-de89df76afd3?w=800&h=800&fit=crop",
        "https://images.unsplash.com/photo-1548036328-c9fa89d128fa?w=800&h=800&fit=crop",
      ]),
      pricePerDay: 95,
      retailValue: 1850,
      condition: "mint",
      color: "Black",
      size: "One Size",
      location: "Sydney, NSW",
      available: true,
      rating: 4.9,
      reviewCount: 34,
      featured: true,
    },
    {
      ownerId: owner.id,
      title: "Gucci Marmont GG Shoulder Bag",
      brand: "Gucci",
      category: "bags",
      description: "The Gucci GG Marmont shoulder bag in matelassé chevron leather. Gold-toned hardware with the iconic GG logo at the front. Comes with Gucci box, dust bag, and authenticity certificate.",
      images: JSON.stringify([
        "https://images.unsplash.com/photo-1614179689702-355944cd0918?w=800&h=800&fit=crop",
        "https://images.unsplash.com/photo-1591561954557-26941169b49e?w=800&h=800&fit=crop",
      ]),
      pricePerDay: 120,
      retailValue: 2400,
      condition: "excellent",
      color: "Dusty Pink",
      size: "Medium",
      location: "Sydney, NSW",
      available: true,
      rating: 5.0,
      reviewCount: 21,
      featured: true,
    },
    {
      ownerId: owner2.id,
      title: "Rolex Datejust 36 Stainless Steel",
      brand: "Rolex",
      category: "watches",
      description: "The quintessential Rolex Datejust 36 in Oystersteel with a jubilee bracelet and white dial. Box and papers from 2021. A statement of understated luxury, perfect for formal occasions or business meetings.",
      images: JSON.stringify([
        "https://images.unsplash.com/photo-1587836374828-4dbafa94cf0e?w=800&h=800&fit=crop",
        "https://images.unsplash.com/photo-1523170335258-f5ed11844a49?w=800&h=800&fit=crop",
      ]),
      pricePerDay: 185,
      retailValue: 12500,
      condition: "mint",
      color: "Silver/White",
      size: "36mm",
      location: "Melbourne, VIC",
      available: true,
      rating: 5.0,
      reviewCount: 18,
      featured: true,
    },
    {
      ownerId: owner2.id,
      title: "Audemars Piguet Royal Oak",
      brand: "Audemars Piguet",
      category: "watches",
      description: "The legendary AP Royal Oak in stainless steel with the iconic integrated bracelet and 'Grande Tapisserie' dial. A horological masterpiece that commands respect in any room.",
      images: JSON.stringify([
        "https://images.unsplash.com/photo-1619946794135-5bc917a27793?w=800&h=800&fit=crop",
        "https://images.unsplash.com/photo-1614890107240-6e6ef0b33e5d?w=800&h=800&fit=crop",
      ]),
      pricePerDay: 350,
      retailValue: 38000,
      condition: "mint",
      color: "Steel Blue",
      size: "41mm",
      location: "Melbourne, VIC",
      available: true,
      rating: 4.8,
      reviewCount: 9,
      featured: false,
    },
    {
      ownerId: owner.id,
      title: "Valentino Off-Shoulder Gown",
      brand: "Valentino",
      category: "dresses",
      description: "A breathtaking Valentino couture off-shoulder gown in ivory silk faille. Floor-length silhouette with corseted bodice. Originally worn once. Dry-cleaned and professionally preserved. For the woman who commands every room.",
      images: JSON.stringify([
        "https://images.unsplash.com/photo-1595777457583-95e059d581b8?w=800&h=800&fit=crop",
        "https://images.unsplash.com/photo-1566174053879-31528523f8ae?w=800&h=800&fit=crop",
      ]),
      pricePerDay: 210,
      retailValue: 8500,
      condition: "mint",
      color: "Ivory",
      size: "AU 8",
      location: "Sydney, NSW",
      available: true,
      rating: 4.9,
      reviewCount: 16,
      featured: true,
    },
    {
      ownerId: owner.id,
      title: "Chanel Classic Flap Bag",
      brand: "Chanel",
      category: "bags",
      description: "The most coveted bag in the world — Chanel Classic Flap in black caviar leather with gold-tone hardware. Medium size, double CC turn-lock closure. Comes with original box, dust bag, and authenticity card. A true heirloom piece.",
      images: JSON.stringify([
        "https://images.unsplash.com/photo-1590874103328-eac38a683ce7?w=800&h=800&fit=crop",
        "https://images.unsplash.com/photo-1548036328-c9fa89d128fa?w=800&h=800&fit=crop",
      ]),
      pricePerDay: 280,
      retailValue: 11500,
      condition: "excellent",
      color: "Black/Gold",
      size: "Medium",
      location: "Sydney, NSW",
      available: true,
      rating: 5.0,
      reviewCount: 41,
      featured: true,
    },
    {
      ownerId: owner2.id,
      title: "Cartier Love Bracelet",
      brand: "Cartier",
      category: "jewellery",
      description: "The iconic Cartier Love Bracelet in 18k yellow gold. Includes original screwdriver and box. An enduring symbol of devotion and luxury, recognised the world over.",
      images: JSON.stringify([
        "https://images.unsplash.com/photo-1611652022419-a9419f74343d?w=800&h=800&fit=crop",
        "https://images.unsplash.com/photo-1506629082955-511b1aa562c8?w=800&h=800&fit=crop",
      ]),
      pricePerDay: 95,
      retailValue: 8200,
      condition: "excellent",
      color: "Yellow Gold",
      size: "17",
      location: "Melbourne, VIC",
      available: true,
      rating: 4.7,
      reviewCount: 28,
      featured: false,
    },
    {
      ownerId: owner.id,
      title: "Saint Laurent Le 5 à 7 Hobo Bag",
      brand: "Saint Laurent",
      category: "bags",
      description: "The effortlessly cool YSL Le 5 à 7 hobo bag in smooth leather with a silver-tone YSL turnlock. Spacious yet refined. Comes with dust bag. A downtown Parisian essential.",
      images: JSON.stringify([
        "https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=800&h=800&fit=crop",
        "https://images.unsplash.com/photo-1584917865442-de89df76afd3?w=800&h=800&fit=crop",
      ]),
      pricePerDay: 110,
      retailValue: 2950,
      condition: "mint",
      color: "Ivory",
      size: "One Size",
      location: "Sydney, NSW",
      available: true,
      rating: 4.8,
      reviewCount: 19,
      featured: false,
    },
    {
      ownerId: owner2.id,
      title: "Louboutin So Kate 120 Stilettos",
      brand: "Christian Louboutin",
      category: "shoes",
      description: "The definitive Christian Louboutin So Kate pump in nude patent leather. 120mm stiletto heel with the iconic red sole. Worn twice. Come with original box and dustbag. The power shoe.",
      images: JSON.stringify([
        "https://images.unsplash.com/photo-1543163521-1bf539c55dd2?w=800&h=800&fit=crop",
        "https://images.unsplash.com/photo-1515347619252-60a4bf4fff4f?w=800&h=800&fit=crop",
      ]),
      pricePerDay: 75,
      retailValue: 1250,
      condition: "excellent",
      color: "Nude",
      size: "EU 38",
      location: "Melbourne, VIC",
      available: true,
      rating: 4.6,
      reviewCount: 12,
      featured: false,
    },
    {
      ownerId: owner.id,
      title: "Hermès Clic H Bracelet",
      brand: "Hermès",
      category: "jewellery",
      description: "Hermès Clic H bracelet in gold-plated metal with epoxy enamel in bright orange. A graphic, minimalist piece from the house of Hermès. Comes with orange box and ribbon.",
      images: JSON.stringify([
        "https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?w=800&h=800&fit=crop",
        "https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?w=800&h=800&fit=crop",
      ]),
      pricePerDay: 55,
      retailValue: 780,
      condition: "mint",
      color: "Orange/Gold",
      size: "PM",
      location: "Sydney, NSW",
      available: true,
      rating: 4.9,
      reviewCount: 31,
      featured: false,
    },
    {
      ownerId: owner2.id,
      title: "Bottega Veneta Jodie Bag",
      brand: "Bottega Veneta",
      category: "bags",
      description: "The sculptural Bottega Veneta Jodie in signature Intrecciato woven leather. A masterclass in understated luxury — no logos, pure craft. Comes with dust bag and certificate.",
      images: JSON.stringify([
        "https://images.unsplash.com/photo-1591561954557-26941169b49e?w=800&h=800&fit=crop",
        "https://images.unsplash.com/photo-1614179689702-355944cd0918?w=800&h=800&fit=crop",
      ]),
      pricePerDay: 140,
      retailValue: 3200,
      condition: "mint",
      color: "Caramel",
      size: "Mini",
      location: "Melbourne, VIC",
      available: true,
      rating: 5.0,
      reviewCount: 7,
      featured: true,
    },
    {
      ownerId: owner.id,
      title: "Alexander McQueen Sequin Dress",
      brand: "Alexander McQueen",
      category: "dresses",
      description: "A show-stopping Alexander McQueen strapless sequin midi dress in midnight black. Boned bodice, fully lined. Dry cleaned after one wear. For those rare occasions that call for true spectacle.",
      images: JSON.stringify([
        "https://images.unsplash.com/photo-1566174053879-31528523f8ae?w=800&h=800&fit=crop",
        "https://images.unsplash.com/photo-1595777457583-95e059d581b8?w=800&h=800&fit=crop",
      ]),
      pricePerDay: 175,
      retailValue: 5200,
      condition: "mint",
      color: "Midnight Black",
      size: "AU 10",
      location: "Sydney, NSW",
      available: true,
      rating: 4.8,
      reviewCount: 14,
      featured: false,
    },
  ];

  for (const listing of seedListings) {
    storage.createListing(listing as InsertListing);
  }

  // Create a sample booking
  const allListings = storage.getListings();
  if (allListings.length > 0) {
    storage.createBooking({
      listingId: allListings[0].id,
      renterId: renter.id,
      startDate: "2026-04-20",
      endDate: "2026-04-23",
      totalPrice: allListings[0].pricePerDay * 3 + allListings[0].pricePerDay * 3 * 0.15,
      serviceFee: allListings[0].pricePerDay * 3 * 0.15,
      status: "confirmed",
      message: "Looking forward to wearing this to the gala!",
    });
  }
}

export const storage = new Storage();
seedDatabase(storage);
