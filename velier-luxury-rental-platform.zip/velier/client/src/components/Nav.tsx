import { Link, useLocation } from "wouter";
import { Search, Menu } from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { VelierMark, VelierWordmark } from "@/components/VelierLogo";

interface NavProps {
  onSearch?: (q: string) => void;
}

export default function Nav({ onSearch }: NavProps) {
  const [location] = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [searchValue, setSearchValue] = useState("");

  const isBrowse = location === "/browse" || location.startsWith("/listing");

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (onSearch) onSearch(searchValue);
  };

  return (
    <header className="sticky top-0 z-50 w-full border-b border-border/60 bg-background/95 backdrop-blur-md">
      <div className="mx-auto max-w-screen-xl px-5 lg:px-10 flex h-16 items-center justify-between gap-4">
        {/* Logo */}
        <Link href="/" className="flex items-center shrink-0 text-foreground hover:text-primary transition-colors">
          <VelierWordmark size={26} />
        </Link>

        {/* Search bar (browse pages) */}
        {isBrowse && (
          <form onSubmit={handleSearch} className="hidden md:flex flex-1 max-w-sm">
            <div className="relative w-full">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                data-testid="input-search"
                type="search"
                placeholder="Search brands, styles..."
                value={searchValue}
                onChange={e => setSearchValue(e.target.value)}
                className="pl-9 bg-muted border-border/60 text-sm h-9 focus-visible:ring-primary/50"
              />
            </div>
          </form>
        )}

        {/* Desktop nav */}
        <nav className="hidden md:flex items-center gap-6">
          <Link href="/browse" className="text-sm text-muted-foreground hover:text-foreground transition-colors tracking-wide uppercase">
            Browse
          </Link>
          <Link href="/list-item" className="text-sm text-muted-foreground hover:text-foreground transition-colors tracking-wide uppercase">
            Lend
          </Link>
          <Link href="/list-item">
            <Button
              data-testid="button-list-item-nav"
              size="sm"
              className="bg-primary text-primary-foreground hover:bg-primary/90 text-xs tracking-widest uppercase font-medium px-4"
            >
              List an Item
            </Button>
          </Link>
        </nav>

        {/* Mobile nav */}
        <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
          <SheetTrigger asChild>
            <Button
              data-testid="button-mobile-menu"
              variant="ghost"
              size="icon"
              className="md:hidden"
              aria-label="Open menu"
            >
              <Menu className="w-5 h-5" />
            </Button>
          </SheetTrigger>
          <SheetContent side="right" className="bg-background border-border/60 w-64">
            <div className="flex flex-col gap-6 pt-8">
              {/* Mobile logo */}
              <VelierWordmark size={22} className="text-foreground mb-2" />
              <div className="divider-gold" />
              <Link href="/browse" onClick={() => setMobileOpen(false)} className="font-display text-2xl font-light tracking-wide hover:text-primary transition-colors">
                Browse
              </Link>
              <Link href="/list-item" onClick={() => setMobileOpen(false)} className="font-display text-2xl font-light tracking-wide hover:text-primary transition-colors">
                Lend
              </Link>
              <div className="divider-gold my-2" />
              <Link href="/list-item" onClick={() => setMobileOpen(false)}>
                <Button className="w-full bg-primary text-primary-foreground text-xs tracking-widest uppercase">
                  List an Item
                </Button>
              </Link>
            </div>
          </SheetContent>
        </Sheet>
      </div>
    </header>
  );
}
