import { Link } from "wouter";
import { Star, MapPin } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import type { Listing } from "@shared/schema";

interface ListingCardProps {
  listing: Listing;
}

const conditionLabel: Record<string, string> = {
  mint: "Mint",
  excellent: "Excellent",
  good: "Good",
};

const categoryLabel: Record<string, string> = {
  bags: "Bag",
  watches: "Watch",
  dresses: "Dress",
  jewellery: "Jewellery",
  shoes: "Shoes",
};

export default function ListingCard({ listing }: ListingCardProps) {
  const images = JSON.parse(listing.images) as string[];
  const primaryImage = images[0];

  return (
    <Link
      href={`/listing/${listing.id}`}
      data-testid={`card-listing-${listing.id}`}
      className="group block rounded-sm overflow-hidden bg-card border border-border/50 card-hover"
    >
      {/* Image */}
      <div className="relative aspect-[3/4] overflow-hidden bg-muted">
        <img
          src={primaryImage}
          alt={listing.title}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
          loading="lazy"
        />
        {/* Overlay gradient */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
        
        {/* Condition badge */}
        <div className="absolute top-3 left-3">
          <span className="inline-flex items-center bg-background/80 backdrop-blur-sm text-foreground text-xs px-2 py-0.5 rounded-sm tracking-wider uppercase border border-border/40">
            {conditionLabel[listing.condition]}
          </span>
        </div>

        {listing.featured && (
          <div className="absolute top-3 right-3">
            <span className="inline-flex items-center bg-primary text-primary-foreground text-xs px-2 py-0.5 rounded-sm tracking-wider uppercase font-medium">
              Featured
            </span>
          </div>
        )}

        {/* Quick price on hover */}
        <div className="absolute bottom-3 left-3 right-3 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
          <p className="font-display text-white text-lg font-light">
            ${listing.pricePerDay}<span className="text-sm text-white/70">/day</span>
          </p>
        </div>
      </div>

      {/* Info */}
      <div className="p-4 space-y-2">
        {/* Brand & category */}
        <div className="flex items-center justify-between gap-2">
          <span className="text-xs text-primary tracking-widest uppercase font-medium font-body">
            {listing.brand}
          </span>
          <span className="text-xs text-muted-foreground tracking-wider uppercase font-body">
            {categoryLabel[listing.category] || listing.category}
          </span>
        </div>

        {/* Title */}
        <h3 className="font-display text-base font-light leading-snug text-foreground line-clamp-2">
          {listing.title}
        </h3>

        {/* Rating & location */}
        <div className="flex items-center justify-between pt-1">
          <div className="flex items-center gap-1.5">
            <Star className="w-3.5 h-3.5 fill-primary text-primary shrink-0" />
            <span className="text-xs text-foreground font-body">
              {listing.rating?.toFixed(1)}
            </span>
            <span className="text-xs text-muted-foreground font-body">
              ({listing.reviewCount})
            </span>
          </div>
          <div className="flex items-center gap-1 text-xs text-muted-foreground font-body">
            <MapPin className="w-3 h-3 shrink-0" />
            <span className="truncate max-w-[80px]">{listing.location.split(",")[0]}</span>
          </div>
        </div>

        {/* Price */}
        <div className="flex items-baseline gap-1.5 pt-1 border-t border-border/40">
          <span className="font-display text-lg font-light text-foreground">
            ${listing.pricePerDay}
          </span>
          <span className="text-xs text-muted-foreground font-body">per day</span>
          <span className="ml-auto text-xs text-muted-foreground font-body">
            RRP ${listing.retailValue.toLocaleString()}
          </span>
        </div>
      </div>
    </Link>
  );
}
