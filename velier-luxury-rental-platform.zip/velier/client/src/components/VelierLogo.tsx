/**
 * Velier — The Veil Mark
 *
 * Concept: "Velier" from Latin *velare* — to veil, to conceal.
 * The mark is an abstract veil descending over an almond eye.
 * Thin filament strokes dissolve at the edges, suggesting something
 * half-seen, half-hidden. The eye form invokes desire, mystery,
 * and the act of looking at something rare. Three cascading drape
 * lines above it evoke fabric — a veil falling across vision.
 *
 * Works at 24px and 240px. Monochrome: uses currentColor.
 */

interface VelierLogoProps {
  /** Rendered width in px (height auto-scales to maintain 1:1 viewBox) */
  size?: number;
  className?: string;
}

export function VelierMark({ size = 32, className = "" }: VelierLogoProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 40 40"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      aria-hidden="true"
      className={className}
    >
      {/* ── Veil drape lines — three cascading arcs descending from above ── */}
      {/* These represent a sheer fabric falling, dissolving at the tips */}

      {/* Top veil arc — widest, lightest */}
      <path
        d="M6 10 C10 4, 30 4, 34 10"
        stroke="currentColor"
        strokeWidth="0.8"
        strokeLinecap="round"
        opacity="0.35"
        fill="none"
      />

      {/* Middle veil arc — slightly tighter */}
      <path
        d="M9 14 C13 8.5, 27 8.5, 31 14"
        stroke="currentColor"
        strokeWidth="0.9"
        strokeLinecap="round"
        opacity="0.6"
        fill="none"
      />

      {/* Lower veil arc — tightest, most solid — transitions into the eye */}
      <path
        d="M11.5 18 C14 13, 26 13, 28.5 18"
        stroke="currentColor"
        strokeWidth="1.0"
        strokeLinecap="round"
        opacity="0.85"
        fill="none"
      />

      {/* ── The Eye — almond form, slightly open ── */}
      {/* Upper lid */}
      <path
        d="M10 22 C13 17.5, 27 17.5, 30 22"
        stroke="currentColor"
        strokeWidth="1.3"
        strokeLinecap="round"
        fill="none"
      />
      {/* Lower lid — slightly shallower, eye is neither fully open nor closed */}
      <path
        d="M10 22 C13 25.5, 27 25.5, 30 22"
        stroke="currentColor"
        strokeWidth="1.3"
        strokeLinecap="round"
        fill="none"
      />

      {/* ── Iris — small perfect circle at the centre ── */}
      <circle
        cx="20"
        cy="22"
        r="2.8"
        stroke="currentColor"
        strokeWidth="1.1"
        fill="none"
      />

      {/* ── Pupil — a single filled dot, the point of focus ── */}
      <circle
        cx="20"
        cy="22"
        r="0.9"
        fill="currentColor"
      />

      {/* ── Veil hem — a single fine horizontal line just below the eye,
           suggesting the edge of fabric resting on the face ── */}
      <line
        x1="13"
        y1="28"
        x2="27"
        y2="28"
        stroke="currentColor"
        strokeWidth="0.6"
        strokeLinecap="round"
        opacity="0.4"
      />
    </svg>
  );
}

/** Full wordmark: mark + "VELIER" logotype */
export function VelierWordmark({ size = 28, className = "" }: VelierLogoProps) {
  return (
    <span className={`inline-flex items-center gap-2.5 ${className}`}>
      <VelierMark size={size} />
      <span
        style={{
          fontFamily: "'Cormorant Garamond', 'Georgia', serif",
          fontWeight: 300,
          letterSpacing: "0.28em",
          fontSize: size * 0.65,
          lineHeight: 1,
          textTransform: "uppercase" as const,
        }}
      >
        Velier
      </span>
    </span>
  );
}
