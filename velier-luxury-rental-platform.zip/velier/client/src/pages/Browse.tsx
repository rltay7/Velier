import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useSearch } from "wouter";
import { SlidersHorizontal, X, ChevronDown } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import Nav from "@/components/Nav";
import ListingCard from "@/components/ListingCard";
import type { Listing } from "@shared/schema";

const CATEGORIES = [
  { key: "all", label: "All" },
  { key: "bags", label: "Bags" },
  { key: "watches", label: "Watches" },
  { key: "dresses", label: "Dresses" },
  { key: "jewellery", label: "Jewellery" },
  { key: "shoes", label: "Shoes" },
];

const BRANDS = ["All Brands", "Prada", "Gucci", "Chanel", "Hermès", "Louis Vuitton", "Rolex", "Cartier", "Valentino", "Saint Laurent", "Bottega Veneta", "Audemars Piguet", "Christian Louboutin", "Alexander McQueen"];

const SORT_OPTIONS = [
  { value: "featured", label: "Featured" },
  { value: "price-asc", label: "Price: Low to High" },
  { value: "price-desc", label: "Price: High to Low" },
  { value: "rating", label: "Top Rated" },
];

export default function Browse() {
  const search = useSearch();
  const params = new URLSearchParams(search);

  const [category, setCategory] = useState(params.get("category") || "all");
  const [brand, setBrand] = useState(params.get("brand") || "");
  const [searchQ, setSearchQ] = useState(params.get("q") || "");
  const [sort, setSort] = useState("featured");

  // Update filters when URL params change
  useEffect(() => {
    const p = new URLSearchParams(search);
    if (p.get("category")) setCategory(p.get("category") || "all");
    if (p.get("brand")) setBrand(p.get("brand") || "");
  }, [search]);

  const queryString = new URLSearchParams({
    ...(category && category !== "all" ? { category } : {}),
    ...(brand && brand !== "All Brands" ? { brand } : {}),
    ...(searchQ ? { search: searchQ } : {}),
  }).toString();

  const { data: listings, isLoading } = useQuery<Listing[]>({
    queryKey: ["/api/listings", queryString],
    queryFn: async () => {
      const res = await fetch(`/api/listings?${queryString}`);
      return res.json();
    },
  });

  const sortedListings = listings ? [...listings].sort((a, b) => {
    if (sort === "price-asc") return a.pricePerDay - b.pricePerDay;
    if (sort === "price-desc") return b.pricePerDay - a.pricePerDay;
    if (sort === "rating") return (b.rating || 0) - (a.rating || 0);
    return (b.featured ? 1 : 0) - (a.featured ? 1 : 0);
  }) : [];

  const FilterContent = () => (
    <div className="space-y-6">
      {/* Brand */}
      <div>
        <p className="text-xs tracking-widest uppercase text-muted-foreground font-body mb-3">Brand</p>
        <div className="space-y-1.5">
          {BRANDS.map(b => (
            <button
              key={b}
              data-testid={`filter-brand-${b.toLowerCase().replace(/\s+/g, "-")}`}
              onClick={() => setBrand(b === "All Brands" ? "" : b)}
              className={`w-full text-left text-sm font-body px-0 py-1 transition-colors ${
                (b === "All Brands" && !brand) || brand === b
                  ? "text-primary font-medium"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              {b}
            </button>
          ))}
        </div>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-background">
      <Nav onSearch={setSearchQ} />

      {/* Page header */}
      <div className="border-b border-border/50 bg-card">
        <div className="mx-auto max-w-screen-xl px-5 lg:px-10 py-10">
          <p className="text-xs tracking-[0.25em] uppercase text-primary font-body font-medium mb-2">Velier Collection</p>
          <h1 className="font-display text-3xl md:text-4xl font-light text-foreground">Browse Luxury Pieces</h1>
        </div>
      </div>

      <div className="mx-auto max-w-screen-xl px-5 lg:px-10 py-8">
        {/* Category tabs */}
        <div className="flex items-center gap-1 overflow-x-auto pb-2 mb-6 scrollbar-none">
          {CATEGORIES.map(cat => (
            <button
              key={cat.key}
              data-testid={`filter-cat-${cat.key}`}
              onClick={() => setCategory(cat.key)}
              className={`shrink-0 text-xs tracking-widest uppercase font-body font-medium px-4 py-2 rounded-sm border transition-all ${
                category === cat.key
                  ? "bg-primary text-primary-foreground border-primary"
                  : "border-border/60 text-muted-foreground hover:text-foreground hover:border-border"
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        <div className="flex gap-8">
          {/* Sidebar filters — desktop */}
          <aside className="hidden lg:block w-48 shrink-0">
            <div className="sticky top-24">
              <p className="text-xs tracking-widest uppercase text-foreground font-body font-semibold mb-5">Filter</p>
              <FilterContent />
            </div>
          </aside>

          {/* Main grid */}
          <div className="flex-1 min-w-0">
            {/* Toolbar */}
            <div className="flex items-center justify-between gap-4 mb-6">
              <p className="text-sm text-muted-foreground font-body">
                {isLoading ? "Loading..." : `${sortedListings.length} piece${sortedListings.length !== 1 ? "s" : ""}`}
              </p>

              <div className="flex items-center gap-2">
                {/* Mobile filter button */}
                <Sheet>
                  <SheetTrigger asChild>
                    <Button
                      data-testid="button-mobile-filter"
                      variant="outline"
                      size="sm"
                      className="lg:hidden border-border text-xs gap-2"
                    >
                      <SlidersHorizontal className="w-3.5 h-3.5" />
                      Filter
                    </Button>
                  </SheetTrigger>
                  <SheetContent side="left" className="bg-background border-border/60 w-64 pt-10">
                    <FilterContent />
                  </SheetContent>
                </Sheet>

                {/* Sort */}
                <Select value={sort} onValueChange={setSort}>
                  <SelectTrigger
                    data-testid="select-sort"
                    className="w-44 border-border/60 text-xs h-9 text-muted-foreground"
                  >
                    <SelectValue placeholder="Sort by" />
                  </SelectTrigger>
                  <SelectContent className="bg-card border-border">
                    {SORT_OPTIONS.map(opt => (
                      <SelectItem key={opt.value} value={opt.value} className="text-xs">
                        {opt.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Active filters */}
            {(brand || (category && category !== "all") || searchQ) && (
              <div className="flex flex-wrap gap-2 mb-5">
                {category && category !== "all" && (
                  <span className="inline-flex items-center gap-1.5 text-xs px-3 py-1.5 bg-accent text-accent-foreground rounded-sm border border-border/60 font-body">
                    {CATEGORIES.find(c => c.key === category)?.label}
                    <button onClick={() => setCategory("all")} className="hover:text-primary"><X className="w-3 h-3" /></button>
                  </span>
                )}
                {brand && (
                  <span className="inline-flex items-center gap-1.5 text-xs px-3 py-1.5 bg-accent text-accent-foreground rounded-sm border border-border/60 font-body">
                    {brand}
                    <button onClick={() => setBrand("")} className="hover:text-primary"><X className="w-3 h-3" /></button>
                  </span>
                )}
                {searchQ && (
                  <span className="inline-flex items-center gap-1.5 text-xs px-3 py-1.5 bg-accent text-accent-foreground rounded-sm border border-border/60 font-body">
                    "{searchQ}"
                    <button onClick={() => setSearchQ("")} className="hover:text-primary"><X className="w-3 h-3" /></button>
                  </span>
                )}
              </div>
            )}

            {/* Grid */}
            {isLoading ? (
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                {Array.from({ length: 9 }).map((_, i) => (
                  <Skeleton key={i} className="aspect-[3/4] rounded-sm bg-muted" />
                ))}
              </div>
            ) : sortedListings.length === 0 ? (
              <div className="text-center py-24">
                <p className="font-display text-2xl font-light text-muted-foreground mb-2">No pieces found</p>
                <p className="text-sm text-muted-foreground font-body">Try adjusting your filters</p>
              </div>
            ) : (
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                {sortedListings.map(listing => (
                  <ListingCard key={listing.id} listing={listing} />
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
