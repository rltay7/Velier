import { useState } from "react";
import { useParams, Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import {
  Star, MapPin, ShieldCheck, ArrowLeft, ChevronLeft, ChevronRight,
  Package, Clock, BadgeCheck, Heart
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import Nav from "@/components/Nav";
import type { Listing, User } from "@shared/schema";

const conditionLabel: Record<string, { label: string; desc: string }> = {
  mint: { label: "Mint", desc: "Like new, no signs of wear." },
  excellent: { label: "Excellent", desc: "Minimal wear, near perfect condition." },
  good: { label: "Good", desc: "Light signs of wear, fully functional." },
};

export default function ListingDetail() {
  const { id } = useParams();
  const [activeImage, setActiveImage] = useState(0);
  const [wishlist, setWishlist] = useState(false);

  const { data: listing, isLoading } = useQuery<Listing>({
    queryKey: ["/api/listings", id],
    queryFn: async () => {
      const res = await fetch(`/api/listings/${id}`);
      if (!res.ok) throw new Error("Not found");
      return res.json();
    },
  });

  const { data: owner } = useQuery<User>({
    queryKey: ["/api/users", listing?.ownerId],
    queryFn: async () => {
      const res = await fetch(`/api/users/${listing!.ownerId}`);
      return res.json();
    },
    enabled: !!listing,
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Nav />
        <div className="mx-auto max-w-screen-xl px-5 lg:px-10 py-10 grid lg:grid-cols-2 gap-12">
          <Skeleton className="aspect-square rounded-sm bg-muted" />
          <div className="space-y-4">
            <Skeleton className="h-6 w-32 bg-muted" />
            <Skeleton className="h-10 w-full bg-muted" />
            <Skeleton className="h-6 w-48 bg-muted" />
            <Skeleton className="h-40 w-full bg-muted" />
          </div>
        </div>
      </div>
    );
  }

  if (!listing) {
    return (
      <div className="min-h-screen bg-background">
        <Nav />
        <div className="flex flex-col items-center justify-center py-32">
          <p className="font-display text-2xl text-muted-foreground">Item not found</p>
          <Link href="/browse"><Button className="mt-6 text-xs tracking-widest uppercase">Back to Browse</Button></Link>
        </div>
      </div>
    );
  }

  const images = JSON.parse(listing.images) as string[];
  const condition = conditionLabel[listing.condition] || { label: listing.condition, desc: "" };

  // Calculate sample pricing
  const days = 3;
  const rentalCost = listing.pricePerDay * days;
  const serviceFee = Math.round(rentalCost * 0.15 * 100) / 100;
  const total = rentalCost + serviceFee;

  return (
    <div className="min-h-screen bg-background">
      <Nav />

      {/* Breadcrumb */}
      <div className="mx-auto max-w-screen-xl px-5 lg:px-10 py-4">
        <Link href="/browse" className="inline-flex items-center gap-1.5 text-xs text-muted-foreground hover:text-primary transition-colors font-body tracking-wide uppercase">
          <ArrowLeft className="w-3.5 h-3.5" />
          Back to Browse
        </Link>
      </div>

      <div className="mx-auto max-w-screen-xl px-5 lg:px-10 pb-20">
        <div className="grid lg:grid-cols-2 gap-10 xl:gap-16">

          {/* ── Image Gallery ────────────────────────────────────────── */}
          <div className="space-y-3">
            {/* Main image */}
            <div className="relative aspect-square overflow-hidden rounded-sm bg-muted">
              <img
                src={images[activeImage]}
                alt={listing.title}
                className="w-full h-full object-cover"
                data-testid="img-listing-main"
              />
              {/* Wishlist */}
              <button
                data-testid="button-wishlist"
                onClick={() => setWishlist(w => !w)}
                className={`absolute top-4 right-4 w-10 h-10 rounded-full flex items-center justify-center backdrop-blur-sm border transition-all ${
                  wishlist
                    ? "bg-primary/20 border-primary text-primary"
                    : "bg-background/60 border-border/60 text-muted-foreground hover:text-primary"
                }`}
              >
                <Heart className={`w-4 h-4 ${wishlist ? "fill-primary" : ""}`} />
              </button>

              {/* Nav arrows */}
              {images.length > 1 && (
                <>
                  <button
                    data-testid="button-prev-image"
                    onClick={() => setActiveImage(i => (i - 1 + images.length) % images.length)}
                    className="absolute left-3 top-1/2 -translate-y-1/2 w-8 h-8 rounded-full bg-background/70 backdrop-blur-sm flex items-center justify-center hover:bg-background/90 transition-colors"
                  >
                    <ChevronLeft className="w-4 h-4" />
                  </button>
                  <button
                    data-testid="button-next-image"
                    onClick={() => setActiveImage(i => (i + 1) % images.length)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 w-8 h-8 rounded-full bg-background/70 backdrop-blur-sm flex items-center justify-center hover:bg-background/90 transition-colors"
                  >
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </>
              )}
            </div>

            {/* Thumbnails */}
            {images.length > 1 && (
              <div className="flex gap-2">
                {images.map((img, i) => (
                  <button
                    key={i}
                    data-testid={`button-thumb-${i}`}
                    onClick={() => setActiveImage(i)}
                    className={`w-20 aspect-square overflow-hidden rounded-sm border-2 transition-all ${
                      activeImage === i ? "border-primary" : "border-transparent opacity-60 hover:opacity-100"
                    }`}
                  >
                    <img src={img} alt="" className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* ── Details ──────────────────────────────────────────────── */}
          <div className="space-y-6">
            {/* Brand & category */}
            <div className="flex items-center justify-between gap-2 flex-wrap">
              <span className="text-xs tracking-[0.25em] uppercase text-primary font-body font-medium">{listing.brand}</span>
              <span className="text-xs tracking-widest uppercase text-muted-foreground font-body">{listing.category}</span>
            </div>

            {/* Title */}
            <h1 className="font-display text-3xl md:text-4xl font-light text-foreground leading-tight">
              {listing.title}
            </h1>

            {/* Rating */}
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-1">
                {[1, 2, 3, 4, 5].map(i => (
                  <Star
                    key={i}
                    className={`w-4 h-4 ${i <= Math.round(listing.rating || 0) ? "fill-primary text-primary" : "text-muted-foreground/30"}`}
                  />
                ))}
              </div>
              <span className="text-sm text-foreground font-body">{listing.rating?.toFixed(1)}</span>
              <span className="text-sm text-muted-foreground font-body">({listing.reviewCount} reviews)</span>
              <div className="flex items-center gap-1 text-sm text-muted-foreground ml-2">
                <MapPin className="w-3.5 h-3.5" />
                {listing.location}
              </div>
            </div>

            {/* Divider */}
            <div className="divider-gold" />

            {/* Price */}
            <div className="flex items-baseline gap-2">
              <span className="font-display text-4xl font-light text-foreground">${listing.pricePerDay}</span>
              <span className="text-muted-foreground font-body">/ day</span>
              <span className="ml-auto text-xs text-muted-foreground font-body">
                RRP <span className="line-through">${listing.retailValue.toLocaleString()}</span>
              </span>
            </div>

            {/* Attributes */}
            <div className="grid grid-cols-3 gap-3">
              {[
                { label: "Condition", value: condition.label },
                { label: "Colour", value: listing.color || "—" },
                { label: "Size", value: listing.size || "—" },
              ].map(attr => (
                <div key={attr.label} className="bg-card border border-border/50 rounded-sm p-3 text-center">
                  <p className="text-xs text-muted-foreground font-body mb-1">{attr.label}</p>
                  <p className="text-sm text-foreground font-body font-medium">{attr.value}</p>
                </div>
              ))}
            </div>

            {/* Description */}
            <div>
              <p className="text-xs tracking-widest uppercase text-muted-foreground font-body mb-2">About This Piece</p>
              <p className="text-sm text-muted-foreground font-body leading-relaxed">{listing.description}</p>
            </div>

            {/* Divider */}
            <div className="divider-gold" />

            {/* Owner card */}
            {owner && (
              <div className="flex items-center gap-4 bg-card border border-border/50 rounded-sm p-4">
                <img
                  src={owner.avatar || ""}
                  alt={owner.name}
                  className="w-12 h-12 rounded-full object-cover shrink-0"
                />
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <p className="text-sm font-medium text-foreground font-body">{owner.name}</p>
                    {owner.verified && <BadgeCheck className="w-3.5 h-3.5 text-primary shrink-0" />}
                  </div>
                  <p className="text-xs text-muted-foreground font-body">{owner.location} · {owner.reviewCount} reviews · {owner.rating?.toFixed(1)} ★</p>
                </div>
              </div>
            )}

            {/* Pricing summary */}
            <div className="bg-card border border-border/50 rounded-sm p-5 space-y-3">
              <p className="text-xs tracking-widest uppercase text-muted-foreground font-body mb-3">Sample Pricing (3 Days)</p>
              {[
                { label: `$${listing.pricePerDay} × 3 days`, value: `$${rentalCost}` },
                { label: "Service fee (15%)", value: `$${serviceFee.toFixed(2)}` },
              ].map(row => (
                <div key={row.label} className="flex justify-between text-sm font-body">
                  <span className="text-muted-foreground">{row.label}</span>
                  <span className="text-foreground">{row.value}</span>
                </div>
              ))}
              <div className="divider-gold" />
              <div className="flex justify-between font-body">
                <span className="text-sm font-medium text-foreground">Total</span>
                <span className="font-display text-lg text-foreground">${total.toFixed(2)}</span>
              </div>
            </div>

            {/* CTA */}
            <Link href={`/book/${listing.id}`}>
              <Button
                data-testid="button-reserve"
                className="w-full bg-primary text-primary-foreground hover:bg-primary/90 h-12 text-xs tracking-[0.2em] uppercase font-medium"
              >
                Reserve This Piece
              </Button>
            </Link>

            {/* Trust signals */}
            <div className="grid grid-cols-3 gap-2 text-center">
              {[
                { icon: ShieldCheck, label: "Authenticated" },
                { icon: Package, label: "Insured" },
                { icon: Clock, label: "Flexible Dates" },
              ].map(({ icon: Icon, label }) => (
                <div key={label} className="flex flex-col items-center gap-1">
                  <Icon className="w-4 h-4 text-primary" />
                  <p className="text-xs text-muted-foreground font-body">{label}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
