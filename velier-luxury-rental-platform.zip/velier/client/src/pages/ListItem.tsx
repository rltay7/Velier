import { useState } from "react";
import { useLocation } from "wouter";
import { useMutation } from "@tanstack/react-query";
import { ArrowLeft, CheckCircle2, Upload, Info } from "lucide-react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import Nav from "@/components/Nav";

const CATEGORIES = ["bags", "watches", "dresses", "jewellery", "shoes"];
const CONDITIONS = ["mint", "excellent", "good"];
const POPULAR_BRANDS = ["Chanel", "Prada", "Gucci", "Hermès", "Louis Vuitton", "Valentino", "Bottega Veneta", "Saint Laurent", "Rolex", "Cartier", "Audemars Piguet", "Bulgari", "Tiffany & Co.", "Christian Louboutin", "Manolo Blahnik", "Other"];

const STEPS = ["Details", "Pricing", "Photos", "Review"];

export default function ListItem() {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const [step, setStep] = useState(0);
  const [submitted, setSubmitted] = useState(false);

  const [form, setForm] = useState({
    brand: "",
    title: "",
    category: "",
    description: "",
    condition: "",
    size: "",
    color: "",
    location: "",
    pricePerDay: "",
    retailValue: "",
  });

  const update = (key: string, val: string) => setForm(f => ({ ...f, [key]: val }));

  const mutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/listings", {
        ownerId: 1,
        title: form.title,
        brand: form.brand,
        category: form.category,
        description: form.description,
        images: JSON.stringify([
          "https://images.unsplash.com/photo-1584917865442-de89df76afd3?w=800&h=800&fit=crop",
        ]),
        pricePerDay: parseFloat(form.pricePerDay) || 100,
        retailValue: parseFloat(form.retailValue) || 1000,
        condition: form.condition || "excellent",
        size: form.size || null,
        color: form.color || null,
        location: form.location || "Sydney, NSW",
        available: true,
        rating: 5.0,
        reviewCount: 0,
        featured: false,
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/listings"] });
      setSubmitted(true);
    },
    onError: () => {
      toast({ title: "Something went wrong", description: "Please try again.", variant: "destructive" });
    },
  });

  if (submitted) {
    return (
      <div className="min-h-screen bg-background">
        <Nav />
        <div className="flex flex-col items-center justify-center py-32 px-5 text-center">
          <CheckCircle2 className="w-16 h-16 text-primary mb-6" />
          <h1 className="font-display text-3xl font-light text-foreground mb-3">Your Item is Listed</h1>
          <p className="text-muted-foreground font-body max-w-sm mb-8">
            Your piece is now live on Velier. We'll notify you when someone makes a booking request.
          </p>
          <div className="flex gap-4 flex-wrap justify-center">
            <Link href="/browse">
              <Button className="bg-primary text-primary-foreground text-xs tracking-widest uppercase">
                Browse Collection
              </Button>
            </Link>
            <Button
              variant="outline"
              className="border-border text-xs tracking-widest uppercase"
              onClick={() => { setSubmitted(false); setStep(0); setForm({ brand: "", title: "", category: "", description: "", condition: "", size: "", color: "", location: "", pricePerDay: "", retailValue: "" }); }}
            >
              List Another Item
            </Button>
          </div>
        </div>
      </div>
    );
  }

  const estimatedMonthly = form.pricePerDay ? (parseFloat(form.pricePerDay) * 12).toFixed(0) : "—";
  const estimatedYearly = form.pricePerDay ? (parseFloat(form.pricePerDay) * 30).toFixed(0) : "—";

  return (
    <div className="min-h-screen bg-background">
      <Nav />

      <div className="mx-auto max-w-screen-xl px-5 lg:px-10 py-6">
        <Link href="/" className="inline-flex items-center gap-1.5 text-xs text-muted-foreground hover:text-primary transition-colors font-body tracking-wide uppercase mb-8">
          <ArrowLeft className="w-3.5 h-3.5" />
          Back
        </Link>

        <div className="max-w-2xl mx-auto">
          {/* Header */}
          <div className="mb-10">
            <p className="text-xs tracking-[0.25em] uppercase text-primary font-body font-medium mb-2">Lend Your Piece</p>
            <h1 className="font-display text-3xl font-light text-foreground">List an Item</h1>
          </div>

          {/* Step indicator */}
          <div className="flex items-center gap-0 mb-10">
            {STEPS.map((s, i) => (
              <div key={s} className="flex items-center flex-1">
                <div className="flex flex-col items-center gap-1.5">
                  <div className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-body font-medium border transition-all ${
                    i < step ? "bg-primary border-primary text-primary-foreground" :
                    i === step ? "border-primary text-primary" :
                    "border-border text-muted-foreground"
                  }`}>
                    {i < step ? "✓" : i + 1}
                  </div>
                  <span className="text-xs text-muted-foreground font-body hidden sm:block">{s}</span>
                </div>
                {i < STEPS.length - 1 && (
                  <div className={`flex-1 h-px mx-2 transition-colors ${i < step ? "bg-primary/50" : "bg-border"}`} />
                )}
              </div>
            ))}
          </div>

          {/* Step 0 — Details */}
          {step === 0 && (
            <div className="space-y-5">
              <div className="space-y-2">
                <Label className="text-xs tracking-widest uppercase text-muted-foreground font-body">Brand *</Label>
                <Select value={form.brand} onValueChange={v => update("brand", v)}>
                  <SelectTrigger data-testid="select-brand" className="bg-card border-border/60 h-11 text-sm focus:ring-primary/50">
                    <SelectValue placeholder="Select brand" />
                  </SelectTrigger>
                  <SelectContent className="bg-card border-border">
                    {POPULAR_BRANDS.map(b => (
                      <SelectItem key={b} value={b} className="text-sm">{b}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label className="text-xs tracking-widest uppercase text-muted-foreground font-body">Item Title *</Label>
                <Input
                  data-testid="input-title"
                  placeholder="e.g. Prada Re-Edition 2005 Nylon Bag"
                  value={form.title}
                  onChange={e => update("title", e.target.value)}
                  className="bg-card border-border/60 h-11 text-sm focus-visible:ring-primary/50"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label className="text-xs tracking-widest uppercase text-muted-foreground font-body">Category *</Label>
                  <Select value={form.category} onValueChange={v => update("category", v)}>
                    <SelectTrigger data-testid="select-category" className="bg-card border-border/60 h-11 text-sm">
                      <SelectValue placeholder="Category" />
                    </SelectTrigger>
                    <SelectContent className="bg-card border-border">
                      {CATEGORIES.map(c => (
                        <SelectItem key={c} value={c} className="text-sm capitalize">{c}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label className="text-xs tracking-widest uppercase text-muted-foreground font-body">Condition *</Label>
                  <Select value={form.condition} onValueChange={v => update("condition", v)}>
                    <SelectTrigger data-testid="select-condition" className="bg-card border-border/60 h-11 text-sm">
                      <SelectValue placeholder="Condition" />
                    </SelectTrigger>
                    <SelectContent className="bg-card border-border">
                      {CONDITIONS.map(c => (
                        <SelectItem key={c} value={c} className="text-sm capitalize">{c}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label className="text-xs tracking-widest uppercase text-muted-foreground font-body">Colour</Label>
                  <Input
                    data-testid="input-color"
                    placeholder="e.g. Black"
                    value={form.color}
                    onChange={e => update("color", e.target.value)}
                    className="bg-card border-border/60 h-11 text-sm focus-visible:ring-primary/50"
                  />
                </div>
                <div className="space-y-2">
                  <Label className="text-xs tracking-widest uppercase text-muted-foreground font-body">Size</Label>
                  <Input
                    data-testid="input-size"
                    placeholder="e.g. AU 8, One Size, 38mm"
                    value={form.size}
                    onChange={e => update("size", e.target.value)}
                    className="bg-card border-border/60 h-11 text-sm focus-visible:ring-primary/50"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label className="text-xs tracking-widest uppercase text-muted-foreground font-body">Description *</Label>
                <Textarea
                  data-testid="input-description"
                  placeholder="Describe your piece — include authenticity details, wear history, and what makes it special..."
                  value={form.description}
                  onChange={e => update("description", e.target.value)}
                  rows={4}
                  className="bg-card border-border/60 text-sm focus-visible:ring-primary/50 resize-none"
                />
              </div>

              <div className="space-y-2">
                <Label className="text-xs tracking-widest uppercase text-muted-foreground font-body">Your Location</Label>
                <Input
                  data-testid="input-location"
                  placeholder="e.g. Sydney, NSW"
                  value={form.location}
                  onChange={e => update("location", e.target.value)}
                  className="bg-card border-border/60 h-11 text-sm focus-visible:ring-primary/50"
                />
              </div>
            </div>
          )}

          {/* Step 1 — Pricing */}
          {step === 1 && (
            <div className="space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label className="text-xs tracking-widest uppercase text-muted-foreground font-body">Daily Rate (AUD) *</Label>
                  <div className="relative">
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground text-sm">$</span>
                    <Input
                      data-testid="input-price-per-day"
                      type="number"
                      placeholder="120"
                      value={form.pricePerDay}
                      onChange={e => update("pricePerDay", e.target.value)}
                      className="bg-card border-border/60 h-11 text-sm pl-7 focus-visible:ring-primary/50"
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label className="text-xs tracking-widest uppercase text-muted-foreground font-body">Retail Value (AUD) *</Label>
                  <div className="relative">
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground text-sm">$</span>
                    <Input
                      data-testid="input-retail-value"
                      type="number"
                      placeholder="2400"
                      value={form.retailValue}
                      onChange={e => update("retailValue", e.target.value)}
                      className="bg-card border-border/60 h-11 text-sm pl-7 focus-visible:ring-primary/50"
                    />
                  </div>
                </div>
              </div>

              {/* Earnings estimator */}
              {form.pricePerDay && (
                <div className="bg-card border border-border/50 rounded-sm p-5">
                  <div className="flex items-center gap-2 mb-4">
                    <Info className="w-4 h-4 text-primary" />
                    <p className="text-xs tracking-widest uppercase text-muted-foreground font-body">Estimated Earnings</p>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    {[
                      { label: "Monthly (12 days)", value: `$${estimatedMonthly}` },
                      { label: "Monthly (30 days)", value: `$${estimatedYearly}` },
                    ].map(row => (
                      <div key={row.label} className="text-center">
                        <p className="font-display text-2xl font-light text-primary">{row.value}</p>
                        <p className="text-xs text-muted-foreground font-body mt-1">{row.label}</p>
                      </div>
                    ))}
                  </div>
                  <p className="text-xs text-muted-foreground font-body mt-4 text-center">
                    Velier takes a 15% service fee from each booking. You keep 85%.
                  </p>
                </div>
              )}
            </div>
          )}

          {/* Step 2 — Photos */}
          {step === 2 && (
            <div className="space-y-5">
              <div className="border-2 border-dashed border-border/60 rounded-sm p-12 flex flex-col items-center justify-center gap-3 text-center hover:border-primary/40 transition-colors cursor-pointer">
                <Upload className="w-8 h-8 text-muted-foreground" />
                <p className="font-display text-lg font-light text-foreground">Upload Photos</p>
                <p className="text-xs text-muted-foreground font-body max-w-xs">
                  Add up to 8 high-quality photos. Include front, back, hardware details, and any authentication cards.
                </p>
                <Button
                  data-testid="button-upload-photos"
                  variant="outline"
                  size="sm"
                  className="mt-2 border-border text-xs tracking-widest uppercase"
                >
                  Choose Files
                </Button>
              </div>
              <div className="bg-accent/30 border border-accent rounded-sm p-4">
                <p className="text-xs text-muted-foreground font-body leading-relaxed">
                  <span className="text-primary font-medium">Photo tips:</span> Natural light, neutral background. Show the dust bag, box, and authenticity card if available. Clear images significantly increase your booking rate.
                </p>
              </div>
              {/* Demo placeholder images */}
              <div className="grid grid-cols-4 gap-2">
                {["https://images.unsplash.com/photo-1584917865442-de89df76afd3?w=200&h=200&fit=crop"].map((img, i) => (
                  <div key={i} className="aspect-square rounded-sm overflow-hidden bg-muted border border-border/50 relative">
                    <img src={img} alt="" className="w-full h-full object-cover" />
                    <div className="absolute inset-0 flex items-center justify-center bg-black/40 opacity-0 hover:opacity-100 transition-opacity">
                      <span className="text-white text-xs">Remove</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Step 3 — Review */}
          {step === 3 && (
            <div className="space-y-5">
              <div className="bg-card border border-border/50 rounded-sm divide-y divide-border/50">
                {[
                  { label: "Brand", value: form.brand || "—" },
                  { label: "Title", value: form.title || "—" },
                  { label: "Category", value: form.category || "—" },
                  { label: "Condition", value: form.condition || "—" },
                  { label: "Daily Rate", value: form.pricePerDay ? `$${form.pricePerDay}` : "—" },
                  { label: "Retail Value", value: form.retailValue ? `$${form.retailValue}` : "—" },
                  { label: "Location", value: form.location || "—" },
                ].map(row => (
                  <div key={row.label} className="flex justify-between px-5 py-3">
                    <span className="text-xs text-muted-foreground font-body tracking-wide uppercase">{row.label}</span>
                    <span className="text-sm text-foreground font-body">{row.value}</span>
                  </div>
                ))}
              </div>

              <div className="bg-accent/20 border border-accent/40 rounded-sm p-4">
                <p className="text-xs text-muted-foreground font-body leading-relaxed">
                  By listing your item, you agree to Velier's <span className="text-primary cursor-pointer hover:underline">Terms of Service</span> and confirm that all information is accurate. Velier provides insurance coverage on all confirmed rentals.
                </p>
              </div>
            </div>
          )}

          {/* Navigation */}
          <div className="flex gap-3 mt-8">
            {step > 0 && (
              <Button
                data-testid="button-prev-step"
                variant="outline"
                onClick={() => setStep(s => s - 1)}
                className="border-border text-xs tracking-widest uppercase flex-1"
              >
                Back
              </Button>
            )}
            {step < STEPS.length - 1 ? (
              <Button
                data-testid="button-next-step"
                onClick={() => setStep(s => s + 1)}
                className="bg-primary text-primary-foreground hover:bg-primary/90 text-xs tracking-[0.2em] uppercase font-medium flex-1"
              >
                Continue
              </Button>
            ) : (
              <Button
                data-testid="button-submit-listing"
                onClick={() => mutation.mutate()}
                disabled={mutation.isPending}
                className="bg-primary text-primary-foreground hover:bg-primary/90 text-xs tracking-[0.2em] uppercase font-medium flex-1"
              >
                {mutation.isPending ? "Submitting..." : "Publish Listing"}
              </Button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
