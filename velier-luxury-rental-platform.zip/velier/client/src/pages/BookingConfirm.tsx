import { useState } from "react";
import { useParams, Link, useLocation } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { ArrowLeft, CalendarDays, CheckCircle2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import Nav from "@/components/Nav";
import type { Listing } from "@shared/schema";

export default function BookingConfirm() {
  const { id } = useParams();
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [message, setMessage] = useState("");
  const [confirmed, setConfirmed] = useState(false);

  const { data: listing, isLoading } = useQuery<Listing>({
    queryKey: ["/api/listings", id],
    queryFn: async () => {
      const res = await fetch(`/api/listings/${id}`);
      return res.json();
    },
  });

  const days = startDate && endDate
    ? Math.max(1, Math.ceil((new Date(endDate).getTime() - new Date(startDate).getTime()) / (1000 * 60 * 60 * 24)))
    : 1;

  const rentalCost = (listing?.pricePerDay || 0) * days;
  const serviceFee = Math.round(rentalCost * 0.15 * 100) / 100;
  const total = rentalCost + serviceFee;

  const mutation = useMutation({
    mutationFn: async () => {
      // Demo user id = 3 (Sofia the renter)
      const response = await apiRequest("POST", "/api/bookings", {
        listingId: parseInt(id!),
        renterId: 3,
        startDate: startDate || new Date().toISOString().split("T")[0],
        endDate: endDate || new Date(Date.now() + 86400000 * days).toISOString().split("T")[0],
        totalPrice: total,
        serviceFee,
        status: "pending",
        message: message || null,
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/bookings"] });
      setConfirmed(true);
    },
    onError: () => {
      toast({ title: "Something went wrong", description: "Please try again.", variant: "destructive" });
    },
  });

  if (confirmed) {
    return (
      <div className="min-h-screen bg-background">
        <Nav />
        <div className="flex flex-col items-center justify-center py-32 px-5 text-center">
          <CheckCircle2 className="w-16 h-16 text-primary mb-6" />
          <h1 className="font-display text-3xl font-light text-foreground mb-3">Booking Requested</h1>
          <p className="text-muted-foreground font-body max-w-sm mb-8">
            Your rental request has been sent to the owner. You'll receive a confirmation once they accept.
          </p>
          <div className="flex gap-4 flex-wrap justify-center">
            <Link href="/browse">
              <Button className="bg-primary text-primary-foreground text-xs tracking-widest uppercase">
                Continue Browsing
              </Button>
            </Link>
            <Link href="/">
              <Button variant="outline" className="border-border text-xs tracking-widest uppercase">
                Back Home
              </Button>
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Nav />

      <div className="mx-auto max-w-screen-xl px-5 lg:px-10 py-6">
        <Link href={`/listing/${id}`} className="inline-flex items-center gap-1.5 text-xs text-muted-foreground hover:text-primary transition-colors font-body tracking-wide uppercase mb-8">
          <ArrowLeft className="w-3.5 h-3.5" />
          Back to Listing
        </Link>

        <div className="grid lg:grid-cols-2 gap-10 xl:gap-16">
          {/* Form */}
          <div>
            <p className="text-xs tracking-[0.25em] uppercase text-primary font-body font-medium mb-2">Reserve</p>
            <h1 className="font-display text-3xl font-light text-foreground mb-8">Confirm Your Booking</h1>

            {isLoading ? (
              <div className="space-y-4">
                {Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-12 bg-muted rounded-sm" />)}
              </div>
            ) : (
              <div className="space-y-6">
                {/* Dates */}
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="start" className="text-xs tracking-widest uppercase text-muted-foreground font-body">From</Label>
                    <Input
                      id="start"
                      data-testid="input-start-date"
                      type="date"
                      value={startDate}
                      onChange={e => setStartDate(e.target.value)}
                      min={new Date().toISOString().split("T")[0]}
                      className="bg-card border-border/60 text-sm h-11 focus-visible:ring-primary/50"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="end" className="text-xs tracking-widest uppercase text-muted-foreground font-body">To</Label>
                    <Input
                      id="end"
                      data-testid="input-end-date"
                      type="date"
                      value={endDate}
                      onChange={e => setEndDate(e.target.value)}
                      min={startDate || new Date().toISOString().split("T")[0]}
                      className="bg-card border-border/60 text-sm h-11 focus-visible:ring-primary/50"
                    />
                  </div>
                </div>

                {/* Renter info */}
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label className="text-xs tracking-widest uppercase text-muted-foreground font-body">First Name</Label>
                    <Input
                      data-testid="input-first-name"
                      placeholder="Sofia"
                      defaultValue="Sofia"
                      className="bg-card border-border/60 text-sm h-11 focus-visible:ring-primary/50"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-xs tracking-widest uppercase text-muted-foreground font-body">Last Name</Label>
                    <Input
                      data-testid="input-last-name"
                      placeholder="Marchetti"
                      defaultValue="Marchetti"
                      className="bg-card border-border/60 text-sm h-11 focus-visible:ring-primary/50"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label className="text-xs tracking-widest uppercase text-muted-foreground font-body">Email</Label>
                  <Input
                    data-testid="input-email"
                    type="email"
                    placeholder="sofia@example.com"
                    defaultValue="user@velier.com"
                    className="bg-card border-border/60 text-sm h-11 focus-visible:ring-primary/50"
                  />
                </div>

                <div className="space-y-2">
                  <Label className="text-xs tracking-widest uppercase text-muted-foreground font-body">Message to Owner (optional)</Label>
                  <Textarea
                    data-testid="input-message"
                    placeholder="Tell the owner about your occasion..."
                    value={message}
                    onChange={e => setMessage(e.target.value)}
                    rows={3}
                    className="bg-card border-border/60 text-sm focus-visible:ring-primary/50 resize-none"
                  />
                </div>

                {/* Payment placeholder */}
                <div className="bg-card border border-border/50 rounded-sm p-4">
                  <p className="text-xs tracking-widest uppercase text-muted-foreground font-body mb-3">Payment</p>
                  <Input
                    data-testid="input-card"
                    placeholder="•••• •••• •••• ••••"
                    defaultValue="•••• •••• •••• 4242"
                    readOnly
                    className="bg-muted border-border/40 text-sm h-11 mb-3"
                  />
                  <p className="text-xs text-muted-foreground font-body">Payment is held securely and only charged after the owner confirms.</p>
                </div>

                <Button
                  data-testid="button-confirm-booking"
                  onClick={() => mutation.mutate()}
                  disabled={mutation.isPending}
                  className="w-full bg-primary text-primary-foreground hover:bg-primary/90 h-12 text-xs tracking-[0.2em] uppercase font-medium"
                >
                  {mutation.isPending ? "Processing..." : "Confirm Booking"}
                </Button>
              </div>
            )}
          </div>

          {/* Summary sidebar */}
          <div>
            {listing && (
              <div className="lg:sticky lg:top-24 space-y-6">
                {/* Item preview */}
                <div className="bg-card border border-border/50 rounded-sm overflow-hidden">
                  <div className="aspect-[16/9] overflow-hidden">
                    <img
                      src={(JSON.parse(listing.images) as string[])[0]}
                      alt={listing.title}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="p-5">
                    <p className="text-xs text-primary tracking-widest uppercase font-body font-medium mb-1">{listing.brand}</p>
                    <p className="font-display text-lg font-light text-foreground">{listing.title}</p>
                  </div>
                </div>

                {/* Pricing */}
                <div className="bg-card border border-border/50 rounded-sm p-5 space-y-3">
                  <p className="text-xs tracking-widest uppercase text-muted-foreground font-body">Booking Summary</p>
                  {[
                    { label: `$${listing.pricePerDay} × ${days} day${days !== 1 ? "s" : ""}`, value: `$${rentalCost.toFixed(2)}` },
                    { label: "Service fee (15%)", value: `$${serviceFee.toFixed(2)}` },
                  ].map(row => (
                    <div key={row.label} className="flex justify-between text-sm font-body">
                      <span className="text-muted-foreground">{row.label}</span>
                      <span className="text-foreground">{row.value}</span>
                    </div>
                  ))}
                  <div className="divider-gold" />
                  <div className="flex justify-between">
                    <span className="text-sm font-medium text-foreground font-body">Total</span>
                    <span className="font-display text-xl text-foreground">${total.toFixed(2)}</span>
                  </div>
                </div>

                <p className="text-xs text-muted-foreground font-body text-center px-4">
                  You won't be charged until the owner confirms your request. Full refund if declined.
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
