import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { ArrowRight, ShieldCheck, Gem, Users, Leaf } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import Nav from "@/components/Nav";
import ListingCard from "@/components/ListingCard";
import { VelierMark } from "@/components/VelierLogo";
import type { Listing } from "@shared/schema";

const CATEGORIES = [
  { key: "bags", label: "Bags", description: "Designer handbags & purses" },
  { key: "watches", label: "Watches", description: "Luxury timepieces" },
  { key: "dresses", label: "Dresses", description: "Couture & occasion wear" },
  { key: "jewellery", label: "Jewellery", description: "Fine jewels & bracelets" },
  { key: "shoes", label: "Shoes", description: "Statement footwear" },
];

const BRANDS = ["Prada", "Gucci", "Chanel", "Hermès", "Louis Vuitton", "Rolex", "Cartier", "Valentino"];

export default function Home() {
  const { data: featured, isLoading } = useQuery<Listing[]>({
    queryKey: ["/api/listings/featured"],
  });

  return (
    <div className="min-h-screen bg-background">
      <Nav />

      {/* ── Hero ─────────────────────────────────────────────────────── */}
      <section className="relative min-h-[92vh] flex items-end pb-20 overflow-hidden">
        {/* Background image */}
        <div className="absolute inset-0">
          <img
            src="https://images.unsplash.com/photo-1490481651871-ab68de25d43d?w=1600&h=1200&fit=crop"
            alt="Luxury fashion"
            className="w-full h-full object-cover object-top"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-black/30 via-black/20 to-black/80" />
          <div className="absolute inset-0 bg-gradient-to-r from-black/40 to-transparent" />
        </div>

        <div className="relative z-10 mx-auto max-w-screen-xl px-5 lg:px-10 w-full">
          {/* Pre-heading */}
          <div className="flex items-center gap-3 mb-6">
            <div className="h-px w-12 bg-primary/70" />
            <p className="text-xs tracking-[0.3em] uppercase text-primary/90 font-body font-medium">The Velier Collection</p>
          </div>

          {/* Heading */}
          <h1 className="font-display font-light text-white leading-[1.05] mb-6" style={{ fontSize: "clamp(2.8rem, 7vw, 6.5rem)" }}>
            Wear the world's<br />
            <em className="not-italic text-gold-gradient">finest pieces.</em>
          </h1>

          {/* Subtext */}
          <p className="text-white/70 text-lg font-body font-light max-w-md mb-10 leading-relaxed">
            Rent authenticated designer bags, watches, dresses and jewellery from private owners across Australia.
          </p>

          {/* CTAs */}
          <div className="flex flex-wrap gap-4">
            <Link href="/browse">
              <Button
                data-testid="button-browse-hero"
                className="bg-primary text-primary-foreground hover:bg-primary/90 text-xs tracking-[0.2em] uppercase font-medium px-8 h-12"
              >
                Browse Collection
                <ArrowRight className="ml-2 w-4 h-4" />
              </Button>
            </Link>
            <Link href="/list-item">
              <Button
                data-testid="button-lend-hero"
                variant="outline"
                className="border-white/40 text-white hover:bg-white/10 hover:border-white/60 text-xs tracking-[0.2em] uppercase font-medium px-8 h-12 bg-transparent"
              >
                Lend Your Items
              </Button>
            </Link>
          </div>
        </div>

        {/* Atmospheric Velier watermark — ghosted, large, in hero bg */}
        <div className="absolute bottom-16 right-16 hidden xl:block opacity-[0.05] pointer-events-none select-none">
          <VelierMark size={300} className="text-white" />
        </div>

        {/* Scroll indicator */}
        <div className="absolute bottom-8 right-10 hidden lg:flex flex-col items-center gap-2 opacity-60">
          <div className="w-px h-12 bg-gradient-to-b from-white/0 to-white/60 animate-pulse" />
          <p className="text-white/50 text-xs tracking-widest uppercase rotate-90 origin-center translate-y-4 font-body">Scroll</p>
        </div>
      </section>

      {/* ── Trust Bar ────────────────────────────────────────────────── */}
      <section className="border-y border-border/50 bg-card">
        <div className="mx-auto max-w-screen-xl px-5 lg:px-10 py-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 md:gap-0 md:divide-x divide-border/50">
            {[
              { icon: ShieldCheck, label: "Authenticated", sub: "Every item verified" },
              { icon: Gem, label: "Luxury Only", sub: "Curated designer pieces" },
              { icon: Users, label: "Peer to Peer", sub: "Real owners, real savings" },
              { icon: Leaf, label: "Sustainable", sub: "Fashion that's circular" },
            ].map(({ icon: Icon, label, sub }) => (
              <div key={label} className="flex flex-col md:flex-row items-center md:items-start gap-3 md:px-8 text-center md:text-left">
                <Icon className="w-5 h-5 text-primary shrink-0 mt-0.5" />
                <div>
                  <p className="text-sm font-medium text-foreground font-body tracking-wide">{label}</p>
                  <p className="text-xs text-muted-foreground font-body mt-0.5">{sub}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Featured Listings ─────────────────────────────────────────── */}
      <section className="mx-auto max-w-screen-xl px-5 lg:px-10 py-20">
        <div className="flex items-end justify-between mb-10">
          <div>
            <p className="text-xs tracking-[0.25em] uppercase text-primary font-body font-medium mb-2">Curated by Velier</p>
            <h2 className="font-display text-3xl md:text-4xl font-light text-foreground">
              Featured Pieces
            </h2>
          </div>
          <Link href="/browse" className="hidden sm:flex items-center gap-2 text-sm text-muted-foreground hover:text-primary transition-colors font-body tracking-wide uppercase text-xs">
            View All <ArrowRight className="w-4 h-4" />
          </Link>
        </div>

        {isLoading ? (
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            {Array.from({ length: 4 }).map((_, i) => (
              <Skeleton key={i} className="aspect-[3/4] rounded-sm bg-muted" />
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            {featured?.slice(0, 8).map(listing => (
              <ListingCard key={listing.id} listing={listing} />
            ))}
          </div>
        )}

        <div className="mt-10 text-center sm:hidden">
          <Link href="/browse">
            <Button variant="outline" className="border-border text-sm tracking-widest uppercase">
              View All <ArrowRight className="ml-2 w-4 h-4" />
            </Button>
          </Link>
        </div>
      </section>

      {/* ── Category Grid ─────────────────────────────────────────────── */}
      <section className="bg-card border-y border-border/50 py-20">
        <div className="mx-auto max-w-screen-xl px-5 lg:px-10">
          <div className="text-center mb-12">
            <p className="text-xs tracking-[0.25em] uppercase text-primary font-body font-medium mb-2">Shop by Category</p>
            <h2 className="font-display text-3xl md:text-4xl font-light text-foreground">Browse the Edit</h2>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
            {CATEGORIES.map(cat => (
              <Link
                key={cat.key}
                href={`/browse?category=${cat.key}`}
                data-testid={`link-category-${cat.key}`}
                className="group relative overflow-hidden rounded-sm border border-border/60 bg-muted/40 hover:border-primary/40 transition-all duration-300 aspect-[3/4] flex flex-col justify-end p-5 cursor-pointer"
              >
                <div className="absolute inset-0 bg-gradient-to-t from-background/90 via-background/20 to-transparent" />
                <div className="relative z-10">
                  <h3 className="font-display text-xl font-light text-foreground group-hover:text-primary transition-colors">
                    {cat.label}
                  </h3>
                  <p className="text-xs text-muted-foreground font-body mt-1">{cat.description}</p>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* ── Brands ───────────────────────────────────────────────────── */}
      <section className="mx-auto max-w-screen-xl px-5 lg:px-10 py-16">
        <div className="text-center mb-10">
          <p className="text-xs tracking-[0.25em] uppercase text-primary font-body font-medium mb-2">Available on Velier</p>
          <h2 className="font-display text-2xl font-light text-muted-foreground">The World's Finest Houses</h2>
        </div>
        <div className="flex flex-wrap justify-center gap-x-10 gap-y-4">
          {BRANDS.map(brand => (
            <Link
              key={brand}
              href={`/browse?brand=${brand}`}
              data-testid={`link-brand-${brand.toLowerCase()}`}
              className="font-display text-lg font-light text-muted-foreground/50 hover:text-primary transition-colors tracking-widest uppercase"
            >
              {brand}
            </Link>
          ))}
        </div>
      </section>

      {/* ── How It Works ──────────────────────────────────────────────── */}
      <section className="bg-card border-y border-border/50 py-20">
        <div className="mx-auto max-w-screen-xl px-5 lg:px-10">
          <div className="text-center mb-14">
            <p className="text-xs tracking-[0.25em] uppercase text-primary font-body font-medium mb-2">The Process</p>
            <h2 className="font-display text-3xl md:text-4xl font-light text-foreground">How Velier Works</h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-px bg-border/30">
            {[
              {
                step: "01",
                title: "Discover",
                body: "Browse our curated catalogue of authenticated luxury items. Filter by brand, category, occasion, or location.",
              },
              {
                step: "02",
                title: "Reserve",
                body: "Select your dates, send a message to the owner, and confirm your rental. Payment is held securely until collection.",
              },
              {
                step: "03",
                title: "Wear",
                body: "Collect or receive your piece. Enjoy it for your occasion, then return it. Simple, circular, and sustainable.",
              },
            ].map(item => (
              <div key={item.step} className="bg-card p-10 flex flex-col gap-4">
                <span className="font-display text-5xl font-light text-primary/30">{item.step}</span>
                <div className="divider-gold w-16" />
                <h3 className="font-display text-xl font-light text-foreground">{item.title}</h3>
                <p className="text-sm text-muted-foreground font-body leading-relaxed">{item.body}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Lender CTA ────────────────────────────────────────────────── */}
      <section className="relative py-24 overflow-hidden">
        <div className="absolute inset-0">
          <img
            src="https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=1600&h=900&fit=crop"
            alt="Luxury wardrobe"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-background/95 via-background/80 to-background/20" />
        </div>

        <div className="relative z-10 mx-auto max-w-screen-xl px-5 lg:px-10">
          <div className="max-w-lg">
            <p className="text-xs tracking-[0.25em] uppercase text-primary font-body font-medium mb-4">For Lenders</p>
            <h2 className="font-display text-3xl md:text-4xl font-light text-foreground mb-4">
              Turn your wardrobe<br />into <em className="not-italic text-gold-gradient">passive income.</em>
            </h2>
            <p className="text-muted-foreground font-body leading-relaxed mb-8">
              List your designer pieces and earn up to 40% of their retail value annually. Full insurance coverage, secure payments, and a community that respects your pieces.
            </p>
            <Link href="/list-item">
              <Button
                data-testid="button-lend-cta"
                className="bg-primary text-primary-foreground hover:bg-primary/90 text-xs tracking-[0.2em] uppercase font-medium px-8 h-12"
              >
                Start Lending <ArrowRight className="ml-2 w-4 h-4" />
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* ── Footer ───────────────────────────────────────────────────── */}
      <footer className="bg-card border-t border-border/50 py-12">
        <div className="mx-auto max-w-screen-xl px-5 lg:px-10">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-10">
            <div className="col-span-2 md:col-span-1">
              <div className="flex items-center gap-2.5 mb-4">
                <VelierMark size={24} className="text-foreground" />
                <span className="font-display text-lg tracking-widest uppercase text-foreground" style={{ letterSpacing: '0.28em', fontWeight: 300 }}>Velier</span>
              </div>
              <p className="text-xs text-muted-foreground font-body leading-relaxed">
                The peer-to-peer luxury rental platform. Access everything. Own nothing.
              </p>
            </div>

            {[
              { heading: "Explore", links: ["Browse All", "Bags", "Watches", "Dresses", "Jewellery"] },
              { heading: "Lend", links: ["List an Item", "How to Lend", "Pricing", "Insurance"] },
              { heading: "Company", links: ["About Us", "Careers", "Press", "Contact"] },
            ].map(col => (
              <div key={col.heading}>
                <p className="text-xs tracking-widest uppercase text-foreground font-body font-medium mb-4">{col.heading}</p>
                <ul className="space-y-2">
                  {col.links.map(link => (
                    <li key={link}>
                      <span className="text-xs text-muted-foreground hover:text-primary transition-colors font-body cursor-pointer">{link}</span>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>

          <div className="divider-gold mb-6" />
          <div className="flex flex-col md:flex-row justify-between items-center gap-3">
            <p className="text-xs text-muted-foreground font-body">© 2026 Velier. All rights reserved.</p>
            <p className="text-xs text-muted-foreground font-body">Australia · New Zealand · Coming Soon</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
